from django.apps import AppConfig


class ShowAppConfig(AppConfig):
    name = 'Show_app'
